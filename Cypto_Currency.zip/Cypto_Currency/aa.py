from datetime import datetime, date, timedelta

now = datetime.now()
today = date.today()
yesterday = today - timedelta(days =1)
dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
print("date and time =", dt_string)
print(yesterday.strftime("%d/%m/%Y"))

#Set up date
#now = datetime.now() #.strftime("%d/%B/%Y %H:%M:%S")
#hour = datetime.now().hour
#start_time = now - timedelta(minite = 300) #Back to 300 minutes
#start_hour = hour - timedelta(hours=300)
#start_time = start_time.strftime("%d/%B/%Y %H:%M:%S")
#today = date.today()
#start_date = today - timedelta(day=400)
#today = today.strftime("%d/%B/%Y")
#start_date = start_date.strftime("%d/%B/%Y")