api_key = 'qDGLqaUp965CxNIW0sF67DMGV6RYJszMSWpy2YSax6o2INcL2AtoGM1KW5Tosf3I'  # EDIT
api_secret = 'iP3PJirumhYOSGFo4iDiciJIaeJleSZ4SxMiBJqVi5G32xfQlmxKIULhNYESmdVo'
tld = 'th'