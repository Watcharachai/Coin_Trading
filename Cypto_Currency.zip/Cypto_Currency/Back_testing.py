import numpy as np
import pandas as pd
# Calculate Portfolio
def cal_port(stat_frame, init_cash=100000):
    # Set init var
    stat_frame['Buy_Sell'] = np.zeros(len(stat_frame.index))
    stat_frame['Cur_cash'] = np.zeros(len(stat_frame.index))
    stat_frame['Num_stock'] = np.zeros(len(stat_frame.index))
    stat_frame['Port_val'] = np.zeros(len(stat_frame.index))
    stat_frame['Total_val'] = np.zeros(len(stat_frame.index))
    stat_frame['Cur_cash'].iloc[0] = init_cash

    # Setup Vars
    buy_price = []
    sell_price = []

    type_buy = []
    type_sell = []

    stat_frame['Cur_cash'].iloc[0] = init_cash

    # Decision
    for num in range(1, len(stat_frame.index)):
        # Buy Condition Short/Mid
        if stat_frame.Position_Mid.iloc[num] == 1 and stat_frame.Position_Long.iloc[num] == 0:
            stat_frame.iloc[num, stat_frame.columns.get_loc('Buy_Sell')] = 'Buy60'  # Status for indexing
            buy_price.append(stat_frame[f'{stat_frame.columns[0]}'].iloc[num])  # Append Price
            type_buy.append('Buy60')  # Status
            stat_frame.iloc[num, stat_frame.columns.get_loc('Num_stock')] = np.floor(
                0.6 * stat_frame['Cur_cash'].iloc[num - 1] / stat_frame[f'{stat_frame.columns[0]}'].iloc[num])
            stat_frame.iloc[num, stat_frame.columns.get_loc('Port_val')] = stat_frame[f'{stat_frame.columns[0]}'].iloc[
                                                                               num] * stat_frame['Num_stock'].iloc[num]
            # Update Current Cash
            stat_frame.iloc[num, stat_frame.columns.get_loc('Cur_cash')] = stat_frame.Cur_cash.iloc[num - 1] - \
                                                                           stat_frame.Port_val.iloc[num]
            # Total Value ==> Cur_cash+Port_Value
            stat_frame.iloc[num, stat_frame.columns.get_loc('Total_val')] = stat_frame.Port_val.iloc[num] + \
                                                                            stat_frame.Cur_cash.iloc[num]

        # Buy Consition Short/Long
        elif stat_frame.Position_Long.iloc[num] == 1:
            stat_frame.iloc[num, stat_frame.columns.get_loc('Buy_Sell')] = 'BuyAll'
            buy_price.append(stat_frame[f'{stat_frame.columns[0]}'].iloc[num])
            type_buy.append('BuyAll')
            stat_frame.iloc[num, stat_frame.columns.get_loc('Num_stock')] = np.floor(
                stat_frame['Cur_cash'].iloc[num - 1] / stat_frame[f'{stat_frame.columns[0]}'].iloc[num])
            stat_frame.iloc[num, stat_frame.columns.get_loc('Port_val')] = stat_frame[f'{stat_frame.columns[0]}'].iloc[
                                                                               num] * stat_frame['Num_stock'].iloc[num]
            # Update Current Cash
            stat_frame.iloc[num, stat_frame.columns.get_loc('Cur_cash')] = stat_frame.Cur_cash.iloc[num - 1] - \
                                                                           stat_frame.Port_val.iloc[num]
            # Total Value ==> Cur_cash+Port_Value
            stat_frame.iloc[num, stat_frame.columns.get_loc('Total_val')] = stat_frame.Port_val.iloc[num] + \
                                                                            stat_frame.Cur_cash.iloc[num]

        # Sell Condition Short/Mid
        elif stat_frame.Position_Mid.iloc[num] == -1 and stat_frame.Position_Long.iloc[num] == 0:
            stat_frame.iloc[num, stat_frame.columns.get_loc('Buy_Sell')] = 'Sell60'
            sell_price.append(stat_frame[f'{stat_frame.columns[0]}'].iloc[num])

            # Conditional Sell ==> Check up what the last order is?
            if type_buy[len(type_buy) - 1] == 'Buy60':  # Buy60 ==> SellAll
                stat_frame.iloc[num, stat_frame.columns.get_loc('Num_stock')] = 0
                sell_val = stat_frame[f'{stat_frame.columns[0]}'].iloc[num] * stat_frame['Num_stock'].iloc[num - 1]
                stat_frame.iloc[num, stat_frame.columns.get_loc('Port_val')] = 0
                # Update Current Cash
                stat_frame.iloc[num, stat_frame.columns.get_loc('Cur_cash')] = stat_frame.Cur_cash.iloc[
                                                                                   num - 1] + sell_val
                # Total Value ==> Cur_cash+Port_Value
                stat_frame.iloc[num, stat_frame.columns.get_loc('Total_val')] = stat_frame.Port_val.iloc[num] + \
                                                                                stat_frame.Cur_cash.iloc[num]

            if type_buy[len(type_buy) - 1] == 'BuyAll':  # Remain 40% of Port
                stat_frame.iloc[num, stat_frame.columns.get_loc('Num_stock')] = stat_frame.Num_stock.iloc[num - 1] * 0.4
                sell_val = stat_frame[f'{stat_frame.columns[0]}'].iloc[num] * stat_frame['Num_stock'].iloc[
                    num - 1] * 0.6
                stat_frame.iloc[num, stat_frame.columns.get_loc('Port_val')] = stat_frame.Num_stock.iloc[num] * \
                                                                               stat_frame[
                                                                                   f'{stat_frame.columns[0]}'].iloc[num]
                # Update Current Cash
                stat_frame.iloc[num, stat_frame.columns.get_loc('Cur_cash')] = stat_frame.Cur_cash.iloc[
                                                                                   num - 1] + sell_val
                # Total Value ==> Cur_cash+Port_Value
                stat_frame.iloc[num, stat_frame.columns.get_loc('Total_val')] = stat_frame.Port_val.iloc[num] + \
                                                                                stat_frame.Cur_cash.iloc[num]


        # Sell Condition Short/Long #Sell_all eventually
        elif stat_frame.Position_Long.iloc[num] == -1:
            stat_frame.iloc[num, stat_frame.columns.get_loc('Buy_Sell')] = 'SellAll'
            sell_price.append(stat_frame[f'{stat_frame.columns[0]}'].iloc[num])

            if type_buy[len(type_buy) - 1] == 'Buy60' or type_buy[len(type_buy) - 1] == 'BuyAll':
                stat_frame.iloc[num, stat_frame.columns.get_loc('Num_stock')] = 0
                sell_val = stat_frame[f'{stat_frame.columns[0]}'].iloc[num] * stat_frame['Num_stock'].iloc[num - 1]
                stat_frame.iloc[num, stat_frame.columns.get_loc('Port_val')] = 0
                # Update Current Cash
                stat_frame.iloc[num, stat_frame.columns.get_loc('Cur_cash')] = stat_frame.Cur_cash.iloc[
                                                                                   num - 1] + sell_val
                # Total Value ==> Cur_cash+Port_Value
                stat_frame.iloc[num, stat_frame.columns.get_loc('Total_val')] = stat_frame.Port_val.iloc[num] + \
                                                                                stat_frame.Cur_cash.iloc[num]

        # Holding Position
        else:
            stat_frame.iloc[num, stat_frame.columns.get_loc('Buy_Sell')] = 'Hold'
            stat_frame.iloc[num, stat_frame.columns.get_loc('Num_stock')] = stat_frame.Num_stock.iloc[num - 1]
            stat_frame.iloc[num, stat_frame.columns.get_loc('Port_val')] = stat_frame[f'{stat_frame.columns[0]}'].iloc[
                                                                               num] * stat_frame['Num_stock'].iloc[num]
            # Remain cash
            stat_frame.iloc[num, stat_frame.columns.get_loc('Cur_cash')] = stat_frame.Cur_cash.iloc[num - 1]
            # Total Value ==> Cur_cash+Port_Value
            stat_frame.iloc[num, stat_frame.columns.get_loc('Total_val')] = stat_frame.Port_val.iloc[num] + \
                                                                            stat_frame.Cur_cash.iloc[num]

    return stat_frame, buy_price, type_buy, sell_price, type_sell